public enum TokenType {
    NUMBER,
    VARIABLE,
    ADD,
    MINUS,
    MULTIPLY,
    DIVIDE,
    RAISE,
    LBRACKET,
    RBRACKET,
    EOI
}