import java.util.ArrayList;
import java.util.List;

public class ParseTree {
    public final String label;
    public final List<ParseTree> children;

    public ParseTree(String label) {
        this.label = label;
        this.children = new ArrayList<>();
    }

    public void addChild(ParseTree child) {
        children.add(child);
    }

    public void print() {
        printTree(this, "", "");
    }

    private void printTree(ParseTree node, String prefix, String childPrefix) {
        System.out.println(prefix + node.label);

        for (int i = 0; i < node.children.size(); i++) {
            ParseTree child = node.children.get(i);
            boolean isLast = (i == node.children.size() - 1);

            printTree(
                    child,
                    childPrefix + (isLast ? "└── " : "├── "),
                    childPrefix + (isLast ? "    " : "│   ")
            );
        }
    }
}
