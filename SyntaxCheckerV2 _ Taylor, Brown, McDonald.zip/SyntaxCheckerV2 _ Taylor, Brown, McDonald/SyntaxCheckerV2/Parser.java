import java.util.List;

public class Parser {
     private final List<Token> tokens;
    private int pos;

    public Parser(List<Token> tokens) {
        this.tokens = tokens;
        this.pos = 0;
    }

    // Look at current token without consuming it
    private Token peek() {
        return tokens.get(pos);
    }

    // Consume and return current token
    private Token consume() {
        return tokens.get(pos++);
    }

    // Consume only if it matches expected type, otherwise throw error
    private Token expect(TokenType type) {
        Token t = peek();
        if (t.getTokenType() != type) {
            throw new RuntimeException(
                    "Syntax error: expected " + type + " but found '" + t.getValue() + "'"
            );
        }
        return consume();
    }

    // Entry point
    public ParseTree parse() {
        ParseTree tree = parseS();
        // After parsing, we should be at EOI
        if (peek().getTokenType() != TokenType.EOI) {
            throw new RuntimeException(
                    "Syntax error: unexpected token '" + peek().getValue() + "'"
            );
        }
        return tree;
    }

    // S → A (('+' | '-') A)*
    // Left associative — we use a loop instead of recursion
    private ParseTree parseS() {
        ParseTree node = parseA();

        while (peek().getTokenType() == TokenType.ADD || peek().getTokenType() == TokenType.MINUS) {
            Token op = consume();
            ParseTree right = parseA();

            // Build a new E node with left, operator, right as children
            ParseTree newNode = new ParseTree("S");
            newNode.addChild(node);
            newNode.addChild(new ParseTree(op.getValue()));
            newNode.addChild(right);
            node = newNode;
        }

        return node;
    }

    // A → B (('*' | '/') B)*
    // Left associative — loop
    private ParseTree parseA() {
        ParseTree node = parseB();

        while (peek().getTokenType() == TokenType.MULTIPLY || peek().getTokenType() == TokenType.DIVIDE) {
            Token op = consume();
            ParseTree right = parseB();

            ParseTree newNode = new ParseTree("A");
            newNode.addChild(node);
            newNode.addChild(new ParseTree(op.getValue()));
            newNode.addChild(right);
            node = newNode;
        }

        return node;
    }

    // B → C ('^' B)?
    // Right associative — we use recursion
    private ParseTree parseB() {
        ParseTree left = parseC();

        if (peek().getTokenType() == TokenType.RAISE) {
            Token op = consume();
            ParseTree right = parseB(); // recursive call for right associativity

            ParseTree node = new ParseTree("B");
            node.addChild(left);
            node.addChild(new ParseTree(op.getValue()));
            node.addChild(right);
            return node;
        }

        return left;
    }

    // C → '(' S ')' | id | num
    private ParseTree parseC() {
        Token t = peek();

        if (t.getTokenType() == TokenType.LBRACKET) {
            consume(); // consume '('
            ParseTree inner = parseS();
            expect(TokenType.RBRACKET); // consume ')', error if missing

            ParseTree node = new ParseTree("C");
            node.addChild(new ParseTree("("));
            node.addChild(inner);
            node.addChild(new ParseTree(")"));
            return node;
        }

        if (t.getTokenType() == TokenType.NUMBER) {
            consume();
            ParseTree node = new ParseTree("C");
            node.addChild(new ParseTree("Number(" + t.getValue() + ")"));
            return node;
        }

        if (t.getTokenType() == TokenType.VARIABLE) {
            consume();
            ParseTree node = new ParseTree("C");
            node.addChild(new ParseTree("Variable(" + t.getValue() + ")"));
            return node;
        }

        throw new RuntimeException(
                "Syntax error: expected a number, variable, or '(' but found '" + t.getValue() + "'"
        );
    }
}
