import java.util.ArrayList;
import java.util.List;

public class Lexer {
    private final String input;
    private int position;

    public Lexer(String input) {
        this.input = input;
        this.position = 0;
    }

    private Token readNumber() {
        StringBuilder sb = new StringBuilder();
        while (position < input.length() &&
                (Character.isDigit(input.charAt(position)) || input.charAt(position) == '.')) {
            sb.append(input.charAt(position));
            position++;
        }
        return new Token(TokenType.NUMBER, sb.toString());
    }

    private Token readIdentifier() {
        StringBuilder sb = new StringBuilder();
        while (position < input.length() &&
                Character.isLetterOrDigit(input.charAt(position))) {
            sb.append(input.charAt(position));
            position++;
        }
        return new Token(TokenType.VARIABLE, sb.toString());
    }

    public List<Token> tokenize() {
        List<Token> tokens = new ArrayList<>();

        while (position < input.length()) {
            char c = input.charAt(position);

            // Skip whitespace
            if (Character.isWhitespace(c)) {
                position++;
                continue;
            }

            // Numbers
            if (Character.isDigit(c)) {
                tokens.add(readNumber());
                continue;
            }

            // Identifiers
            if (Character.isLetter(c)) {
                tokens.add(readIdentifier());
                continue;
            }

            // Operators 
            switch (c) {
                case '+': tokens.add(new Token(TokenType.ADD,   "+")); position++; break;
                case '-': tokens.add(new Token(TokenType.MINUS,  "-")); position++; break;
                case '*': tokens.add(new Token(TokenType.MULTIPLY,   "*")); position++; break;
                case '/': tokens.add(new Token(TokenType.DIVIDE,  "/")); position++; break;
                case '^': tokens.add(new Token(TokenType.RAISE,  "^")); position++; break;
                case '(': tokens.add(new Token(TokenType.LBRACKET, "(")); position++; break;
                case ')': tokens.add(new Token(TokenType.RBRACKET, ")")); position++; break;
                default:
                    throw new RuntimeException(
                            "Unexpected character '" + c + "' at position " + position
                    );
            }
        }

        tokens.add(new Token(TokenType.EOI, ""));
        return tokens;
    }
}
