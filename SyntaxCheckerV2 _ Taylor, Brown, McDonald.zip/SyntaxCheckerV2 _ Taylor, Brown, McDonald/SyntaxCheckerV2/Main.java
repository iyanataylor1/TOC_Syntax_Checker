import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("Choose an option:");
            System.out.println("1. Run predefined test cases");
            System.out.println("2. Enter your own expressions");
            System.out.print("Enter 1 or 2: ");
            choice = scanner.nextInt();
            scanner.nextLine(); 

            if (choice == 1) {
                testCases();
            } else if (choice == 2) {
                userInput();
            } else {
                System.out.println("Invalid choice. Please enter 1 or 2.");
            }
        } while (choice != 1 && choice != 2);

        scanner.close();
    }

    private static void testCases() {
        List<String> testExpressions = new ArrayList<>();

        testExpressions.add("5 - 4");
        testExpressions.add("3 * (2 - 1)");
        testExpressions.add("4 * (2 + 1) ^ 9");
        testExpressions.add("7 + 3 * (12 / 3)");
        testExpressions.add("10 / (5 - 5)");

        testExpressions.add("5(7 - 8)");
        testExpressions.add("3*-(2 + 1)");
        testExpressions.add("6 * (8 + 5) / ");
        testExpressions.add("4 + * 3");
        testExpressions.add("(2 + 3");

        for (String expression : testExpressions) {
            System.out.println("\nTesting: " + expression);

            try {
                Lexer lexer = new Lexer(expression);
                List<Token> tokens = lexer.tokenize();

                Parser parser = new Parser(tokens);
                ParseTree tree = parser.parse();

                System.out.println("Result: Valid");
                System.out.println("\nParse Tree:");
                tree.print();

            } catch (RuntimeException e) {
                System.out.println("Result: Invalid");
                System.out.println("Error: " + e.getMessage());
            }
        }
    }

    private static void userInput() {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\nEnter arithmetic expression (or 'quit' to exit): ");
            String expression = scanner.nextLine();

            if (expression.equalsIgnoreCase("quit")) {
                System.out.println("Goodbye!");
                break;
            }

            if (expression.trim().isEmpty()) {
                System.out.println("Please enter an expression.");
                continue;
            }

            try {
                Lexer lexer = new Lexer(expression);
                List<Token> tokens = lexer.tokenize();

                Parser parser = new Parser(tokens);
                ParseTree tree = parser.parse();

                System.out.println("Result: Valid");
                System.out.println("\nParse Tree:");
                tree.print();

            } catch (RuntimeException e) {
                System.out.println("Result: Invalid");
                System.out.println("Error: " + e.getMessage());
                System.out.println("Please try again.");
            }
        }

        scanner.close();
    }
}